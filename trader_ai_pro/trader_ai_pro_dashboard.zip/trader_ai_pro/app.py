"""TRADER AI PRO - dashboard Streamlit (paper trading / backtest uniquement, aucun argent réel)."""
import streamlit as st
import pandas as pd
from trader_ai_pro import data, report, DISCLAIMER
from trader_ai_pro.session import Session, WARMUP
from trader_ai_pro.backtest import run_splits
from trader_ai_pro.risk import PROFILES

st.set_page_config(page_title="TRADER AI PRO", page_icon="📈", layout="centered")
st.title("📈 TRADER AI PRO")
st.caption("Paper trading & backtest — aucun argent réel. " + DISCLAIMER)

with st.sidebar:
    source = st.selectbox("Source de données", ["Synthétique (test)", "Binance (crypto, public)", "Fichier CSV"])
    risk = st.selectbox("Risque", ["LOW", "MEDIUM", "HIGH"], index=1)
    capital = st.number_input("Capital virtuel ($)", 1000, 1_000_000, 10_000, step=1000)
    df, asset, ppy = None, "", 24 * 365
    if source.startswith("Synth"):
        regime = st.selectbox("Régime simulé", list(data.REGIMES))
        df, asset = data.synthetic(regime, 3000), f"SYNTH-{regime}"
    elif source.startswith("Binance"):
        asset = st.selectbox("Actif", ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT"])
        tf = st.selectbox("Timeframe", ["1h", "4h", "1d"])
        ppy = {"1h": 24 * 365, "4h": 6 * 365, "1d": 365}[tf]
        df = data.binance_klines(asset, tf, 1000)
        if df is None:
            st.error("Binance indisponible (réseau ou région bloquée). Essaie un autre réseau ou le mode synthétique.")
    else:
        up = st.file_uploader("CSV (time,open,high,low,close)", type="csv")
        if up:
            df, asset = data.load_csv(up), "CSV"

if df is None:
    st.info("Choisis une source de données dans le menu (≡ en haut à gauche).")
    st.stop()
problems = data.validate_ohlc(df)
if problems or len(df) < WARMUP + 50:
    st.error("Données invalides ou insuffisantes : " + ("; ".join(problems) or f"minimum {WARMUP + 50} barres"))
    st.stop()

cfg = dict(asset=asset, risk_level=risk, initial_equity=float(capital), periods_per_year=ppy)
tab1, tab2, tab3, tab4 = st.tabs(["Analyse IA", "Backtest", "Journal", "Risque"])

with tab1:
    s = Session(df, **cfg)
    dec = s.decide(len(df) - 1)
    c1, c2, c3 = st.columns(3)
    c1.metric("Signal", dec.action.replace("_", " "))
    c2.metric("Score", f"{dec.score:.0f}/100")
    c3.metric("Dernier prix", f"{df['close'].iloc[-1]:,.2f}")
    st.code(report.explain(asset, dec), language=None)
    st.dataframe(pd.DataFrame([{"Moteur": k, "Score (-1 à +1)": None if v.score is None else round(v.score, 2)}
                               for k, v in dec.engines.items()]), hide_index=True)
    st.line_chart(df["close"].tail(300))

with tab2:
    if st.button("Lancer le backtest", type="primary"):
        res = run_splits(df, **cfg)
        st.session_state["res"] = res
    res = st.session_state.get("res")
    if res:
        for name, r in res.items():
            m = r["metrics"]
            st.subheader({"train": "Entraînement", "validation": "Validation", "out_of_sample": "Hors échantillon"}[name])
            a, b, c = st.columns(3)
            a.metric("Rendement", f"{m['return_pct']:+.2f}%"); b.metric("Drawdown", f"{m['max_drawdown_pct']:.2f}%")
            c.metric("Trades", m["trades"])
            st.caption(report.summary(m))
        oos = res["out_of_sample"]["equity"]
        if oos:
            st.line_chart(pd.Series([e for _, e in oos], index=[t for t, _ in oos]))
        if any(r["risk_events"] for r in res.values()):
            st.warning("Le kill switch / une limite de perte s'est déclenché pendant le test.")
    else:
        st.write("Appuie sur le bouton pour tester la stratégie (coûts inclus).")

with tab3:
    res = st.session_state.get("res")
    trades = [t for r in res.values() for t in r["trades"]] if res else []
    if trades:
        jdf = pd.DataFrame(trades).drop(columns=["entry_reasons"])
        st.dataframe(jdf)
        st.download_button("Télécharger le journal (CSV)", jdf.to_csv(index=False), "journal.csv")
    else:
        st.write("Lance d'abord un backtest.")

with tab4:
    p = PROFILES[risk]
    st.write(f"Profil **{risk}**")
    st.table(pd.DataFrame({"Paramètre": ["Risque par trade", "Perte max/jour", "Perte max/semaine", "Drawdown max (kill switch)",
                                         "Positions max", "Exposition max (x capital)"],
                           "Valeur": [f"{p.risk_per_trade:.2%}", f"{p.max_daily_loss:.0%}", f"{p.max_weekly_loss:.0%}",
                                      f"{p.max_drawdown:.0%}", p.max_positions, f"{p.max_exposure:.1f}x"]}))
    st.caption("Stop-loss obligatoire. Taille jamais augmentée après une perte.")

st.divider()
st.caption(DISCLAIMER)
