# TRADER AI PRO — MVP (étapes 1 à 9 + paper trading)

Plateforme de trading algorithmique ÉDUCATIVE. Aucune performance n'est garantie.
Les performances passées ne garantissent pas les performances futures. Le trading comporte un risque de perte en capital.

## Lancer
    python3 -m unittest discover -s tests -v     # 24 tests
    python3 demo.py --regime bull --risk MEDIUM  # données SYNTHÉTIQUES
    python3 demo.py --csv mes_donnees.csv --risk LOW   # colonnes: time,open,high,low,close

## Modules (indépendants et testés)
data · technical · macro (fondamental/macro/sentiment) · quant · signal (scoring + NO TRADE) ·
risk (+ kill switch) · session (exécution simulée + positions) · backtest (train/validation/OOS) · paper

## Garanties de conception
- Signal à la clôture de la barre i, exécution à l'ouverture de i+1 (pas de look-ahead, testé).
- Coûts : spread, commission, slippage. Stop-loss obligatoire, trailing stop, pas de pyramiding.
- Taille de position calculée sur le capital courant : jamais d'augmentation après une perte.
- Kill switch : limites quotidienne / hebdomadaire / drawdown, réarmement manuel.
- Macro/fondamental/sentiment : aucune donnée inventée ; sans connecteur, ces moteurs sont « indisponibles »
  et les poids sont renormalisés.

## Limites actuelles (à lire)
- Données de test synthétiques : elles servent à vérifier le code, pas à évaluer une stratégie.
- Pas encore : connecteurs de données réelles, dashboard web, authentification, chiffrement des clés, LIVE.
- LiveBroker lève une erreur tant que l'intégration d'une API officielle n'est pas faite.

## Dashboard (Streamlit)
    pip install -r requirements.txt
    streamlit run app.py
Déploiement gratuit : GitHub + share.streamlit.io (fichier principal : app.py).
