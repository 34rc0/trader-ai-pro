import math, sys, os, unittest
import numpy as np, pandas as pd
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from trader_ai_pro import data, technical, quant, signal as sig, macro
from trader_ai_pro.types import EngineResult
from trader_ai_pro.risk import RiskEngine, make_profile
from trader_ai_pro.session import Session, Costs, WARMUP
from trader_ai_pro.backtest import run_splits, parameter_lab, split_indices
from trader_ai_pro.paper import PaperTrader


def last_tech(regime, seed=1):
    """Score technique moyen sur toute la période (un seul point serait trop bruité)."""
    t = technical.compute(data.synthetic(regime, 1500, seed)).iloc[200:]
    return float(np.mean([technical.evaluate(r).score for _, r in t.iterrows()]))


class Engines(unittest.TestCase):
    def test_no_lookahead(self):
        df = data.synthetic("bull", 600, 3)
        for mod in (technical, quant):
            full, part = mod.compute(df), mod.compute(df.iloc[:400])
            pd.testing.assert_frame_equal(full.iloc[:400], part)

    def test_bull_market(self): self.assertGreater(last_tech("bull"), 0.2)
    def test_bear_market(self): self.assertLess(last_tech("bear"), -0.2)

    def test_sideways_weaker_than_trend(self):
        def avg(reg):
            t = technical.compute(data.synthetic(reg, 1500, 2)).iloc[200:]
            return np.mean([abs(technical.evaluate(r).score) for _, r in t.iterrows()])
        self.assertLess(avg("range"), avg("bull"))

    def test_high_and_low_volatility(self):
        for reg in ("high_vol", "low_vol"):
            r = Session(data.synthetic(reg, 800, 4), risk_level="LOW").run()
            self.assertIn("metrics", r)
        low = technical.compute(data.synthetic("low_vol", 500, 1))["atr_pct"].iloc[-1]
        high = technical.compute(data.synthetic("high_vol", 500, 1))["atr_pct"].iloc[-1]
        self.assertGreater(high, low * 5)
        ok, _ = RiskEngine(make_profile("LOW"), 1e4).allow_entry(high, 0)
        self.assertFalse(ok)


class Signals(unittest.TestCase):
    def R(self, n, s): return EngineResult(n, s)

    def test_contradictory_signals_no_trade(self):
        d = sig.combine({"technical": self.R("technical", .9), "quant": self.R("quant", .8),
                         "macro": self.R("macro", -.8)})
        self.assertEqual(d.action, "NO_TRADE")

    def test_missing_data_no_trade(self):
        d = sig.combine({"technical": self.R("technical", None), "quant": self.R("quant", .9)})
        self.assertEqual(d.action, "NO_TRADE")
        df = data.synthetic("bull", 400, 1)
        df.iloc[-1, df.columns.get_loc("close")] = np.nan
        self.assertTrue(data.validate_ohlc(df))
        s = Session(df)
        self.assertEqual(s.decide(len(df) - 1).action, "NO_TRADE")

    def test_strong_signal_and_labels(self):
        d = sig.combine({"technical": self.R("technical", .95), "quant": self.R("quant", .9)})
        self.assertEqual(d.action, "BUY")
        self.assertEqual(sig.label(39), "PAS DE TRADE"); self.assertEqual(sig.label(75), "SIGNAL FORT")
        self.assertEqual(sig.label(95), "SIGNAL TRÈS FORT")

    def test_macro_without_data_is_unavailable(self):
        self.assertIsNone(macro.evaluate_macro(None).score)


class Risk(unittest.TestCase):
    def test_size_never_exceeds_risk_or_exposure(self):
        r = RiskEngine(make_profile("MEDIUM"), 10000)
        size = r.position_size(10000, 100, 98)
        self.assertLessEqual(size * 2, 10000 * 0.005 + 1e-9)
        tiny = r.position_size(10000, 100, 99.99)  # stop très proche -> plafonné par l'exposition
        self.assertLessEqual(tiny * 100, 10000 * 2.0 + 1e-6)
        self.assertEqual(r.position_size(10000, 100, 100), 0)

    def test_no_size_increase_after_losses(self):
        r = RiskEngine(make_profile("MEDIUM"), 10000)
        self.assertLess(r.position_size(9000, 100, 98), r.position_size(10000, 100, 98))

    def test_daily_limit_and_drawdown_kill_switch(self):
        r = RiskEngine(make_profile("LOW"), 10000)
        t0 = pd.Timestamp("2024-03-05 09:00")
        r.update(t0, 10000); r.update(t0 + pd.Timedelta(hours=1), 9850)
        self.assertTrue(r.daily_halt); self.assertFalse(r.allow_entry(0.001, 0)[0])
        r.update(t0 + pd.Timedelta(days=1), 9850)           # nouveau jour : halte quotidienne levée
        self.assertFalse(r.daily_halt)
        r.update(t0 + pd.Timedelta(days=2), 9100)           # drawdown 9 % > 8 % (LOW)
        self.assertTrue(r.killed)
        r.update(t0 + pd.Timedelta(days=9), 10000)          # même après rebond : toujours arrêté
        self.assertTrue(r.killed and r.halted())
        r.reset(); self.assertFalse(r.halted())

    def test_max_positions(self):
        r = RiskEngine(make_profile("LOW"), 10000)
        self.assertFalse(r.allow_entry(0.001, 1)[0])


class SessionTests(unittest.TestCase):
    def test_trades_respect_risk(self):
        s = Session(data.synthetic("bull", 2000, 5), risk_level="MEDIUM"); r = s.run()
        self.assertGreater(len(r["trades"]), 0)
        for t in r["trades"]:
            self.assertLessEqual(t["risk_amount"], 10000 * 1.5 * 0.005)  # marge pour équité > initiale
            self.assertIsNotNone(t["stop_loss"])

    def test_loss_streak_on_range_market_is_survivable(self):
        r = Session(data.synthetic("range", 3000, 6), risk_level="LOW").run()
        eq = [e for _, e in r["equity"]]
        self.assertGreater(min(eq), 10000 * (1 - 0.08) - 1)  # n'a pas dépassé le drawdown LOW (ou arrêt)

    def test_kill_switch_stops_everything(self):
        s = Session(data.synthetic("bull", 2000, 5), risk_overrides={"max_drawdown": 0.0005}); r = s.run()
        self.assertTrue(s.risk.killed); self.assertIsNone(s.pos); self.assertTrue(r["risk_events"])
        last_exit = max(t["exit_time"] for t in r["trades"])
        self.assertEqual(sum(1 for t in r["trades"] if t["entry_time"] > last_exit), 0)

    def test_major_event_blocks_entries(self):
        df = data.synthetic("bull", 2000, 5)
        evs = list(df.index[WARMUP::12])
        s = Session(df, events=evs); r = s.run()
        for t in r["trades"]:
            sig_ts = t["entry_time"] - pd.Timedelta(hours=1)
            self.assertTrue(all(abs(sig_ts - e) > pd.Timedelta(hours=2) for e in evs))

    def test_execution_error_opens_nothing(self):
        def boom(order): raise ConnectionError("broker down")
        s = Session(data.synthetic("bull", 1500, 5), fill_hook=boom); r = s.run()
        self.assertEqual(len(r["trades"]), 0); self.assertTrue(r["execution_errors"])

    def test_slippage_and_costs_reduce_result(self):
        df = data.synthetic("bull", 2000, 5)
        free = Session(df, costs=Costs(0, 0, 0)).run()["metrics"]["return_pct"]
        costly = Session(df, costs=Costs(0.001, 0.0005, 0.0005)).run()["metrics"]["return_pct"]
        self.assertGreater(free, costly)

    def test_entry_at_next_open_not_signal_bar(self):
        s = Session(data.synthetic("bull", 1500, 5)); r = s.run()
        t = r["trades"][0]; open_px = s.df.loc[t["entry_time"], "open"]
        self.assertAlmostEqual(t["entry"] / open_px, 1 + (0.0002 / 2 + 0.0001) * (1 if t["direction"] == "LONG" else -1), 6)


class Lab(unittest.TestCase):
    def test_splits_are_chronological_and_disjoint(self):
        sp = split_indices(1000)
        self.assertLessEqual(sp["train"][1], sp["validation"][0]); self.assertLessEqual(sp["validation"][1], sp["out_of_sample"][0])
        res = run_splits(data.synthetic("bull", 3000, 7))
        self.assertEqual(set(res), {"train", "validation", "out_of_sample"})

    def test_parameter_lab_runs(self):
        r = parameter_lab(data.synthetic("bull", 3000, 7), {"stop_mult": [1.5, 2.5], "min_score": [50, 65]})
        self.assertIn("warning", r)


class Resilience(unittest.TestCase):
    def feed_from(self, df, fail_at=()):
        it = iter(range(len(df))); state = {"n": 0}
        def fetch():
            state["n"] += 1
            if state["n"] in fail_at or (fail_at == "all"): raise ConnectionError("API indisponible")
            i = next(it); return df.index[i], df.iloc[i][["open", "high", "low", "close"]].to_dict()
        return data.ResilientFeed(fetch, retries=2)

    def test_api_unavailable(self):
        pt = PaperTrader(data.synthetic("bull", 300, 1).iloc[:200], data.ResilientFeed(lambda: 1 / 0), mode="PAPER")
        for _ in range(5): self.assertFalse(pt.tick())
        self.assertEqual(pt.missed, 5); self.assertEqual(len(pt.session.trades), 0)

    def test_disconnection_and_recovery_and_bad_bar(self):
        full = data.synthetic("bull", 700, 1); hist, live = full.iloc[:300], full.iloc[300:]
        feed = self.feed_from(live, fail_at={3, 4, 5, 6})
        pt = PaperTrader(hist, feed)
        ok = [pt.tick() for _ in range(40)]
        self.assertIn(False, ok); self.assertIn(True, ok); self.assertGreater(pt.missed, 0)
        ts = pt.session.df.index[-1] + pd.Timedelta(hours=1)
        pt.feed = data.ResilientFeed(lambda: (ts, {"open": 1, "high": 0.5, "low": 2, "close": float("nan")}))
        self.assertFalse(pt.tick()); self.assertEqual(pt.rejected, 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
