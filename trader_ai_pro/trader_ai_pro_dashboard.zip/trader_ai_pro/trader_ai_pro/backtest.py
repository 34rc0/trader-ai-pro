"""Laboratoire : découpage chronologique train / validation / out-of-sample, grille de paramètres."""
import itertools
from .session import Session, WARMUP


def split_indices(n, ratios=(0.6, 0.2, 0.2)):
    a = int(n * ratios[0])
    b = a + int(n * ratios[1])
    return {"train": (WARMUP, a), "validation": (a, b), "out_of_sample": (b, n)}


def run_backtest(df, start=None, end=None, **cfg):
    return Session(df, **cfg).run(start, end)


def run_splits(df, ratios=(0.6, 0.2, 0.2), **cfg):
    return {k: run_backtest(df, s, e, **cfg) for k, (s, e) in split_indices(len(df), ratios).items()}


def parameter_lab(df, grid, min_trades=5, **cfg):
    """Choix des paramètres sur TRAIN uniquement ; validation pour confirmer ; OOS lu une seule fois."""
    s_tr, e_tr = split_indices(len(df))["train"]
    best, best_sharpe = None, None
    for combo in itertools.product(*grid.values()):
        params = dict(zip(grid.keys(), combo))
        m = run_backtest(df, s_tr, e_tr, **{**cfg, **params})["metrics"]
        if m["trades"] >= min_trades and (best is None or m["sharpe"] > best_sharpe):
            best, best_sharpe = params, m["sharpe"]
    if best is None:
        return {"params": None, "warning": "aucun jeu de paramètres avec assez de trades"}
    sp = split_indices(len(df))
    out = {k: run_backtest(df, *sp[k], **{**cfg, **best})["metrics"] for k in sp}
    overfit = out["validation"]["sharpe"] < 0 or out["validation"]["sharpe"] < 0.5 * out["train"]["sharpe"]
    return {"params": best, "metrics": out,
            "warning": "RISQUE DE SURAPPRENTISSAGE: la validation se dégrade fortement" if overfit else None}
