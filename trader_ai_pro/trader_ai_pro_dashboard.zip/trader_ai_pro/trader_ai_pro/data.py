"""DATA ENGINE : chargement, validation, données synthétiques (tests) et flux résilient."""
import numpy as np
import pandas as pd

COLUMNS = ["open", "high", "low", "close"]

REGIMES = {  # (drift par barre, volatilité par barre)
    "bull": (0.0006, 0.004),
    "bear": (-0.0006, 0.004),
    "range": (0.0, 0.003),
    "high_vol": (0.0, 0.012),
    "low_vol": (0.0001, 0.0008),
}


def synthetic(regime="bull", n=1500, seed=0, start="2024-01-01", freq="h", price0=100.0):
    """Données SYNTHÉTIQUES pour tester le code. Ce ne sont PAS des données de marché."""
    drift, vol = REGIMES[regime]
    rng = np.random.default_rng(seed)
    eps = rng.normal(0, vol, n)
    x = np.empty(n)
    mu = np.log(price0)
    x[0] = mu
    for t in range(1, n):
        if regime == "range":  # retour à la moyenne (Ornstein-Uhlenbeck)
            x[t] = x[t - 1] + 0.05 * (mu - x[t - 1]) + eps[t]
        else:
            x[t] = x[t - 1] + drift + eps[t]
    close = np.exp(x)
    prev = np.concatenate([[close[0]], close[:-1]])
    open_ = prev * (1 + rng.normal(0, vol * 0.1, n))
    high = np.maximum(open_, close) * (1 + np.abs(rng.normal(0, vol * 0.5, n)))
    low = np.minimum(open_, close) * (1 - np.abs(rng.normal(0, vol * 0.5, n)))
    idx = pd.date_range(start, periods=n, freq=freq)
    return pd.DataFrame({"open": open_, "high": high, "low": low, "close": close,
                         "volume": rng.lognormal(10, 0.3, n)}, index=idx)


def load_csv(path):
    """CSV avec colonnes : time (ou date), open, high, low, close[, volume]."""
    df = pd.read_csv(path)
    tcol = next((c for c in df.columns if c.lower() in ("time", "date", "datetime", "timestamp")), None)
    if tcol is None:
        raise ValueError("colonne temporelle introuvable (time/date/datetime/timestamp)")
    df.index = pd.to_datetime(df.pop(tcol))
    df.columns = [c.lower() for c in df.columns]
    return df.sort_index()


def validate_ohlc(df):
    """Retourne la liste des problèmes de qualité de données (vide = OK)."""
    problems = []
    for c in COLUMNS:
        if c not in df.columns:
            problems.append(f"colonne manquante: {c}")
    if problems:
        return problems
    if df[COLUMNS].isna().any().any():
        problems.append("valeurs manquantes (NaN)")
    if not df.index.is_monotonic_increasing:
        problems.append("index non trié")
    if df.index.has_duplicates:
        problems.append("horodatages dupliqués")
    if (df["high"] < df["low"]).any():
        problems.append("high < low")
    if (df[COLUMNS] <= 0).any().any():
        problems.append("prix <= 0")
    return problems


def validate_bar(bar):
    """Valide une barre unique (dict) avant de l'ajouter au flux."""
    try:
        vals = [float(bar[c]) for c in COLUMNS]
    except (KeyError, TypeError, ValueError):
        return False
    if any(np.isnan(v) or v <= 0 for v in vals):
        return False
    return bar["high"] >= bar["low"]


class ResilientFeed:
    """Enveloppe un fournisseur de données : réessaie, puis renvoie None (jamais d'exception)."""

    def __init__(self, fetch, retries=3):
        self.fetch, self.retries = fetch, retries
        self.failures = 0

    def next_bar(self):
        for _ in range(self.retries):
            try:
                bar = self.fetch()
                return bar
            except Exception:
                self.failures += 1
        return None


def binance_klines(symbol="BTCUSDT", interval="1h", limit=1000, base="https://api.binance.com"):
    """Bougies publiques Binance (aucune clé, aucun compte). Retourne None si indisponible."""
    import requests
    try:
        r = requests.get(base + "/api/v3/klines", params={"symbol": symbol, "interval": interval,
                                                         "limit": limit}, timeout=10)
        r.raise_for_status()
        rows = r.json()
        df = pd.DataFrame(rows).iloc[:, :6]
        df.columns = ["time", "open", "high", "low", "close", "volume"]
        df.index = pd.to_datetime(df.pop("time"), unit="ms")
        return df.astype(float)
    except Exception:
        return None
