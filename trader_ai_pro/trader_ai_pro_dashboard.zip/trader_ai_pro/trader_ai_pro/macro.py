"""FUNDAMENTAL / MACRO ENGINES (Soros / Druckenmiller).

Hors-ligne : aucune donnée macro n'est inventée. Un connecteur de données fournit des facteurs
signés dans [-1, 1] POUR L'ACTIF (positif = favorable à la hausse). Sans données -> moteur indisponible.
"""
import numpy as np
from .types import EngineResult

FUND_KEYS = ("inflation", "gdp", "unemployment", "earnings")
MACRO_KEYS = ("central_bank", "rates")


def _mean(inputs, keys):
    vals = [float(inputs[k]) for k in keys if inputs and inputs.get(k) is not None]
    return float(np.clip(np.mean(vals), -1, 1)) if vals else None


def evaluate_fundamental(inputs):
    s = _mean(inputs, FUND_KEYS)
    if s is None:
        return EngineResult("fundamental", None, risks=["données fondamentales indisponibles"])
    why = ["contexte fondamental " + ("favorable" if s > 0 else "défavorable")] if s else []
    return EngineResult("fundamental", s, why)


def evaluate_macro(inputs):
    s = _mean(inputs, MACRO_KEYS)
    if s is None:
        return EngineResult("macro", None, risks=["données macro indisponibles"])
    risks = []
    geo = (inputs or {}).get("geopolitical_risk")
    if geo is not None and geo > 0.7:
        s *= 0.5
        risks.append("risque géopolitique élevé")
    why = ["contexte macro " + ("favorable" if s > 0 else "défavorable")] if s else []
    return EngineResult("macro", s, why, risks)


def evaluate_sentiment(inputs):
    v = (inputs or {}).get("sentiment")
    if v is None:
        return EngineResult("sentiment", None, risks=["sentiment indisponible"])
    return EngineResult("sentiment", float(np.clip(v, -1, 1)))
