"""Interface broker. LIVE volontairement NON implémenté dans ce MVP (étape 11 : API officielle)."""
from abc import ABC, abstractmethod


class Broker(ABC):
    @abstractmethod
    def place_order(self, asset, side, size, stop_loss, take_profit=None): ...


class LiveBroker(Broker):
    def __init__(self, confirmed=False):
        if not confirmed:
            raise PermissionError("Le mode LIVE exige une confirmation explicite de l'utilisateur.")

    def place_order(self, *a, **k):
        raise NotImplementedError("Intégration d'une API officielle de broker : étape ultérieure.")
