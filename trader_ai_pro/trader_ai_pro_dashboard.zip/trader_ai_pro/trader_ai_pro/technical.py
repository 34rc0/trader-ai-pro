"""TECHNICAL ENGINE (Livermore / Paul Tudor Jones / Dennis) - indicateurs causaux uniquement."""
import numpy as np
import pandas as pd
from .types import EngineResult


def compute(df):
    c, h, l = df["close"], df["high"], df["low"]
    o = pd.DataFrame(index=df.index)
    o["close"] = c
    for n in (20, 50, 100):
        o[f"sma{n}"] = c.rolling(n).mean()
    ema12 = c.ewm(span=12, adjust=False, min_periods=12).mean()
    ema26 = c.ewm(span=26, adjust=False, min_periods=26).mean()
    macd = ema12 - ema26
    o["macd_hist"] = macd - macd.ewm(span=9, adjust=False, min_periods=9).mean()
    d = c.diff()
    gain = d.clip(lower=0).ewm(alpha=1 / 14, adjust=False, min_periods=14).mean()
    loss = (-d.clip(upper=0)).ewm(alpha=1 / 14, adjust=False, min_periods=14).mean()
    o["rsi"] = np.where(loss == 0, 100.0, 100 - 100 / (1 + gain / loss.replace(0, np.nan)))
    o.loc[gain.isna() | loss.isna(), "rsi"] = np.nan
    tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
    o["atr"] = tr.ewm(alpha=1 / 14, adjust=False, min_periods=14).mean()
    o["atr_pct"] = o["atr"] / c
    o["don_hi20"] = h.rolling(20).max().shift(1)   # shift(1): jamais la barre courante
    o["don_lo20"] = l.rolling(20).min().shift(1)
    o["don_hi55"] = h.rolling(55).max().shift(1)
    o["don_lo55"] = l.rolling(55).min().shift(1)
    o["roc20"] = c / c.shift(20) - 1
    return o


_NEEDED = ["sma50", "sma100", "macd_hist", "rsi", "atr", "don_hi20", "don_lo20", "roc20"]


def evaluate(row):
    if row[_NEEDED].isna().any():
        return EngineResult("technical", None, risks=["indicateurs techniques indisponibles"])
    c = row["close"]
    comps, reasons, risks = {}, {}, []
    if c > row["sma50"] > row["sma100"]:
        comps["trend"], reasons["trend"] = 1.0, ("tendance haussière", 1)
    elif c < row["sma50"] < row["sma100"]:
        comps["trend"], reasons["trend"] = -1.0, ("tendance baissière", -1)
    else:
        comps["trend"] = 0.3 * np.sign(c - row["sma50"])
    mom = (np.sign(row["macd_hist"]) + np.sign(row["roc20"])) / 2
    comps["momentum"] = mom
    if mom != 0:
        reasons["momentum"] = ("momentum " + ("positif" if mom > 0 else "négatif"), np.sign(mom))
    if c > row["don_hi55"] if not np.isnan(row["don_hi55"]) else False:
        comps["breakout"] = 1.0
    elif c < row["don_lo55"] if not np.isnan(row["don_lo55"]) else False:
        comps["breakout"] = -1.0
    elif c > row["don_hi20"]:
        comps["breakout"] = 0.7
    elif c < row["don_lo20"]:
        comps["breakout"] = -0.7
    else:
        comps["breakout"] = 0.0
    if comps["breakout"] != 0:
        reasons["breakout"] = ("breakout " + ("haussier" if comps["breakout"] > 0 else "baissier") + " confirmé",
                               np.sign(comps["breakout"]))
    score = 0.4 * comps["trend"] + 0.3 * comps["momentum"] + 0.3 * comps["breakout"]
    score = float(np.clip(score, -1, 1))
    if row["rsi"] > 75 and score > 0:
        score *= 0.8
        risks.append("RSI en surachat")
    if row["rsi"] < 25 and score < 0:
        score *= 0.8
        risks.append("RSI en survente")
    side = np.sign(score)
    why = [txt for txt, s in reasons.values() if s == side] if side else []
    return EngineResult("technical", score, why, risks)
