"""PAPER / DEMO : même moteur que le backtest, alimenté barre par barre. Aucun argent réel."""
from .data import validate_bar
from .session import Session


class PaperTrader:
    def __init__(self, history_df, feed, **cfg):
        self.session = Session(history_df, mode=cfg.pop("mode", "PAPER"), **cfg)
        self.feed = feed
        self.missed = 0
        self.rejected = 0

    def tick(self):
        item = self.feed.next_bar()
        if item is None:           # API indisponible / déconnexion : on ne fait rien, stops conservés
            self.missed += 1
            return False
        ts, bar = item
        if not validate_bar(bar):  # donnée corrompue : rejetée
            self.rejected += 1
            return False
        self.session.append_bar(ts, bar)
        return True
