"""EXECUTION + POSITION MANAGER simulés (backtest / paper / demo).

Anti look-ahead : le signal est calculé à la CLÔTURE de la barre i, l'ordre est exécuté à
l'OUVERTURE de la barre i+1. Coûts : spread, commission, slippage. Stop-loss obligatoire,
trailing stop (ratchet), pyramiding désactivé (1 position par actif).
"""
from dataclasses import dataclass
import pandas as pd

from . import technical, quant, macro, signal as sig
from .risk import RiskEngine, make_profile
from .metrics import compute_metrics
from .types import EngineResult

WARMUP = 150


@dataclass
class Costs:
    spread: float = 0.0002
    commission: float = 0.0001   # par côté, fraction du notionnel
    slippage: float = 0.0001


class Position:
    def __init__(self, **kw):
        self.__dict__.update(kw)


class Session:
    def __init__(self, df, asset="ASSET", risk_level="MEDIUM", initial_equity=10000.0, costs=None,
                 macro_inputs=None, min_score=60, stop_mult=2.0, trail_mult=3.0, tp_mult=None,
                 events=None, event_window_hours=2, fill_hook=None, risk_overrides=None,
                 periods_per_year=24 * 365, mode="BACKTEST"):
        self.df = df.copy()
        self.asset, self.mode = asset, mode
        self.costs = costs or Costs()
        self.macro_inputs = macro_inputs
        self.min_score, self.stop_mult, self.trail_mult, self.tp_mult = min_score, stop_mult, trail_mult, tp_mult
        self.events = [pd.Timestamp(e) for e in (events or [])]
        self.event_window = pd.Timedelta(hours=event_window_hours)
        self.fill_hook = fill_hook
        self.ppy = periods_per_year
        self.initial_equity = initial_equity
        self.risk = RiskEngine(make_profile(risk_level, **(risk_overrides or {})), initial_equity)
        self.realized = 0.0
        self.pos = None
        self.pending = None
        self.pending_exit = None
        self.trades, self.equity_curve = [], []
        self.execution_errors, self.log = [], []
        self.last_decision = None
        self._prepare()

    # ---------- indicateurs ----------
    def _prepare(self):
        self.ind_t = technical.compute(self.df)
        self.ind_q = quant.compute(self.df)

    def decide(self, i):
        ts = self.df.index[i]
        if self.df[["open", "high", "low", "close"]].iloc[i].isna().any():
            return sig.combine({"technical": EngineResult("technical", None, risks=["barre invalide"]),
                                "quant": EngineResult("quant", None, risks=["barre invalide"])}, self.min_score)
        res = {"technical": technical.evaluate(self.ind_t.iloc[i]),
               "quant": quant.evaluate(self.ind_q.iloc[i]),
               "fundamental": macro.evaluate_fundamental(self.macro_inputs),
               "macro": macro.evaluate_macro(self.macro_inputs),
               "sentiment": macro.evaluate_sentiment(self.macro_inputs)}
        dec = sig.combine(res, self.min_score)
        if self._in_blackout(ts):
            dec.risks.append("événement économique majeur proche")
        return dec

    def _in_blackout(self, ts):
        return any(abs(ts - e) <= self.event_window for e in self.events)

    # ---------- comptabilité ----------
    def _equity(self, price):
        unreal = self.pos.side * (price - self.pos.entry) * self.pos.size if self.pos else 0.0
        return self.initial_equity + self.realized + unreal

    def _adverse(self):
        return self.costs.spread / 2 + self.costs.slippage

    # ---------- exécution ----------
    def _fill_entry(self, i):
        dec, atr = self.pending
        self.pending = None
        bar, ts = self.df.iloc[i], self.df.index[i]
        side = 1 if dec.action == "BUY" else -1
        price = bar["open"] * (1 + side * self._adverse())
        stop = price - side * self.stop_mult * atr
        tp = price + side * self.tp_mult * atr if self.tp_mult else None
        equity = self._equity(bar["open"])
        size = self.risk.position_size(equity, price, stop)
        if size <= 0:
            self.log.append((ts, "ordre annulé: taille nulle"))
            return
        try:
            if self.fill_hook:
                self.fill_hook({"asset": self.asset, "side": side, "price": price, "size": size})
        except Exception as e:  # erreur d'exécution : on n'ouvre RIEN
            self.execution_errors.append((ts, repr(e)))
            return
        comm = self.costs.commission * price * size
        self.realized -= comm
        self.pos = Position(side=side, entry=price, stop=stop, init_stop=stop, tp=tp, size=size, idx=i, time=ts,
                            risk_amount=abs(price - stop) * size, score=dec.score, reasons=list(dec.reasons),
                            entry_comm=comm, strategy="ensemble(" + ",".join(
                                k for k, v in dec.engines.items() if v.score and v.score * dec.direction > 0) + ")")

    def _exit(self, i, raw_price, reason):
        p, ts = self.pos, self.df.index[i]
        price = raw_price * (1 - p.side * self._adverse())
        comm = self.costs.commission * price * p.size
        pnl = p.side * (price - p.entry) * p.size - comm - p.entry_comm
        self.realized += p.side * (price - p.entry) * p.size - comm
        eq = self.initial_equity + self.realized
        self.trades.append({
            "entry_time": p.time, "exit_time": ts, "asset": self.asset,
            "direction": "LONG" if p.side > 0 else "SHORT", "entry": p.entry, "stop_loss": p.init_stop,
            "take_profit": p.tp, "size": p.size, "risk_amount": p.risk_amount, "strategy": p.strategy,
            "score": p.score, "entry_reasons": p.reasons, "exit_reason": reason, "exit": price,
            "pnl": pnl, "drawdown_pct": (self.risk.peak - eq) / self.risk.peak * 100,
            "duration_bars": i - p.idx})
        self.pos = None

    def _check_stops(self, i):
        b, p = self.df.iloc[i], self.pos
        if p.side == 1:
            if b["low"] <= p.stop:
                return self._exit(i, min(b["open"], p.stop), "stop-loss" if p.stop == p.init_stop else "trailing stop")
            if p.tp and b["high"] >= p.tp:
                return self._exit(i, max(b["open"], p.tp), "take-profit")
        else:
            if b["high"] >= p.stop:
                return self._exit(i, max(b["open"], p.stop), "stop-loss" if p.stop == p.init_stop else "trailing stop")
            if p.tp and b["low"] <= p.tp:
                return self._exit(i, min(b["open"], p.tp), "take-profit")
        atr = self.ind_t["atr"].iloc[i]
        if self.trail_mult and atr == atr:
            new = b["close"] - p.side * self.trail_mult * atr
            p.stop = max(p.stop, new) if p.side == 1 else min(p.stop, new)

    # ---------- boucle ----------
    def on_bar(self, i):
        bar, ts = self.df.iloc[i], self.df.index[i]
        if self.pending and not self.pos:
            self._fill_entry(i)
        if self.pos and self.pending_exit:
            self._exit(i, bar["open"], self.pending_exit)
        self.pending_exit = None
        if self.pos:
            self._check_stops(i)
        eq = self._equity(bar["close"])
        self.equity_curve.append((ts, eq))
        self.risk.update(ts, eq)
        if self.risk.halted():
            self.pending = None
            if self.pos:
                self._exit(i, bar["close"], "kill switch / limite de perte")
            self.last_decision = sig.combine({}, self.min_score)
            return
        dec = self.decide(i)
        self.last_decision = dec
        if self.pos is None and self.pending is None and dec.action in ("BUY", "SELL"):
            ok, why = self.risk.allow_entry(self.ind_t["atr_pct"].iloc[i], 0)
            if ok and not self._in_blackout(ts):
                self.pending = (dec, self.ind_t["atr"].iloc[i])
            else:
                self.log.append((ts, "entrée bloquée: " + (why or "événement économique")))
        elif self.pos and dec.direction and dec.direction != self.pos.side and dec.score >= self.min_score:
            self.pending_exit = "signal inverse"

    def run(self, start=None, end=None):
        start = WARMUP if start is None else max(start, WARMUP)
        end = len(self.df) if end is None else end
        for i in range(start, end):
            self.on_bar(i)
        if self.pos:
            self._exit(end - 1, self.df["close"].iloc[end - 1], "fin de période")
            self.equity_curve[-1] = (self.equity_curve[-1][0], self.initial_equity + self.realized)
        return self.result()

    def append_bar(self, ts, bar):
        """Paper/demo : ajoute une barre en direct puis traite la décision."""
        self.df = pd.concat([self.df, pd.DataFrame([bar], index=[ts])])
        self._prepare()
        self.on_bar(len(self.df) - 1)

    def result(self):
        eq = [self.initial_equity] + [e for _, e in self.equity_curve]
        return {"metrics": compute_metrics(eq, self.trades, self.ppy), "trades": self.trades,
                "equity": self.equity_curve, "risk_events": self.risk.events,
                "execution_errors": self.execution_errors}
