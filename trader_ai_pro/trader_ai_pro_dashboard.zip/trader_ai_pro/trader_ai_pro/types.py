from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class EngineResult:
    name: str
    score: Optional[float]          # -1 (baissier) .. +1 (haussier) ; None = donnée indisponible
    reasons: List[str] = field(default_factory=list)
    risks: List[str] = field(default_factory=list)


@dataclass
class Decision:
    action: str                     # BUY / SELL / WAIT / NO_TRADE
    score: float                    # 0..100
    label: str
    direction: int
    reasons: List[str] = field(default_factory=list)
    risks: List[str] = field(default_factory=list)
    engines: dict = field(default_factory=dict)
