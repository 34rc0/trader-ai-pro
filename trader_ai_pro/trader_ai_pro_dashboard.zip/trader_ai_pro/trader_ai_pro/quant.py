"""QUANT ENGINE : statistiques générales (aucun algorithme propriétaire). Pas d'optimisation ici."""
import numpy as np
import pandas as pd
from .types import EngineResult


def compute(df):
    c = df["close"]
    o = pd.DataFrame(index=df.index)
    ret = np.log(c).diff()
    o["vol20"] = ret.rolling(20).std()
    o["vol_rank"] = o["vol20"].rolling(250, min_periods=120).rank(pct=True)
    o["mom_z"] = (c / c.shift(20) - 1) / (o["vol20"] * np.sqrt(20))
    o["dev_z"] = (c - c.rolling(50).mean()) / c.rolling(50).std()
    return o


def evaluate(row):
    if row[["mom_z", "dev_z", "vol_rank"]].isna().any():
        return EngineResult("quant", None, risks=["statistiques insuffisantes"])
    score = float(np.tanh(row["mom_z"] / 2))
    reasons, risks = [], []
    if abs(row["mom_z"]) > 1:
        reasons.append("momentum statistiquement significatif (z=%.1f)" % row["mom_z"])
    if abs(row["dev_z"]) > 2.5:
        score *= 0.5
        risks.append("écart statistique extrême vs moyenne (risque de retour)")
    if row["vol_rank"] > 0.9:
        risks.append("volatilité historique dans le top 10 %")
    return EngineResult("quant", score, reasons if score else [], risks)


def correlation(df_a, df_b, window=60):
    """Corrélation glissante des rendements entre deux actifs."""
    ra, rb = np.log(df_a["close"]).diff(), np.log(df_b["close"]).diff()
    return ra.rolling(window).corr(rb)
