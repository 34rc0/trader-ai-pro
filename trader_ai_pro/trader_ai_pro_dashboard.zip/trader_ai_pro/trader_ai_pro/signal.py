"""SIGNAL ENGINE : scoring pondéré. « NO TRADE » est une décision valide."""
from .types import Decision

WEIGHTS = {"technical": 0.30, "fundamental": 0.25, "macro": 0.20, "quant": 0.15, "sentiment": 0.10}
REQUIRED = ("technical", "quant")
CONTRADICTION = 0.4


def label(score):
    if score < 40: return "PAS DE TRADE"
    if score < 60: return "SIGNAL FAIBLE"
    if score < 75: return "SIGNAL MOYEN"
    if score < 90: return "SIGNAL FORT"
    return "SIGNAL TRÈS FORT"


def combine(results, min_score=60):
    """results: dict nom -> EngineResult. Les poids sont renormalisés sur les moteurs disponibles."""
    risks = [r for res in results.values() for r in res.risks]
    avail = {k: v for k, v in results.items() if v.score is not None}
    missing = [k for k in REQUIRED if k not in avail]
    if missing:
        return Decision("NO_TRADE", 0.0, "PAS DE TRADE", 0,
                        ["données manquantes: " + ", ".join(missing)], risks, results)
    pos = [k for k, v in avail.items() if v.score > CONTRADICTION]
    neg = [k for k, v in avail.items() if v.score < -CONTRADICTION]
    if pos and neg:
        return Decision("NO_TRADE", 0.0, "PAS DE TRADE", 0,
                        ["signaux contradictoires: haussier=%s / baissier=%s" % (pos, neg)], risks, results)
    wsum = sum(WEIGHTS[k] for k in avail)
    w = sum(WEIGHTS[k] * avail[k].score for k in avail) / wsum
    score = abs(w) * 100
    direction = 1 if w > 0 else -1 if w < 0 else 0
    reasons = [r for k, v in avail.items() if v.score * direction > 0 for r in v.reasons]
    if score >= min_score and direction:
        action = "BUY" if direction > 0 else "SELL"
    elif score >= 40:
        action = "WAIT"
    else:
        action = "NO_TRADE"
    return Decision(action, round(score, 1), label(score), direction, reasons, risks, results)
