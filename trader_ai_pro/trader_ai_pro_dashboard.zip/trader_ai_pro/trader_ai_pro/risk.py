"""RISK ENGINE + KILL SWITCH. Priorité : protéger le capital."""
from dataclasses import dataclass, replace


@dataclass(frozen=True)
class RiskProfile:
    risk_per_trade: float
    max_daily_loss: float
    max_weekly_loss: float
    max_drawdown: float
    max_positions: int
    max_exposure: float      # notionnel max / capital, par actif
    vol_limit: float         # ATR/prix max pour ouvrir une position (dépend du timeframe)


PROFILES = {
    "LOW": RiskProfile(0.0025, 0.01, 0.03, 0.08, 1, 1.0, 0.010),
    "MEDIUM": RiskProfile(0.005, 0.02, 0.05, 0.12, 2, 2.0, 0.020),
    "HIGH": RiskProfile(0.01, 0.03, 0.08, 0.20, 3, 3.0, 0.040),
}


def make_profile(level="MEDIUM", **overrides):
    return replace(PROFILES[level], **overrides)


class RiskEngine:
    def __init__(self, profile, equity0):
        self.p = profile
        self.peak = equity0
        self.day_key = self.week_key = None
        self.day_start = self.week_start = equity0
        self.daily_halt = self.weekly_halt = self.killed = False
        self.events = []

    def position_size(self, equity, entry, stop):
        """Taille basée UNIQUEMENT sur le capital courant : jamais d'augmentation pour 'se refaire'."""
        dist = abs(entry - stop)
        if equity <= 0 or dist <= 0 or entry <= 0:
            return 0.0
        units = equity * self.p.risk_per_trade / dist
        return min(units, equity * self.p.max_exposure / entry)

    def update(self, ts, equity):
        dk, wk = ts.date(), (ts.isocalendar()[0], ts.isocalendar()[1])
        if dk != self.day_key:
            self.day_key, self.day_start, self.daily_halt = dk, equity, False
        if wk != self.week_key:
            self.week_key, self.week_start, self.weekly_halt = wk, equity, False
        self.peak = max(self.peak, equity)
        if not self.daily_halt and (self.day_start - equity) / self.day_start >= self.p.max_daily_loss:
            self.daily_halt = True
            self.events.append((ts, "perte quotidienne maximale atteinte"))
        if not self.weekly_halt and (self.week_start - equity) / self.week_start >= self.p.max_weekly_loss:
            self.weekly_halt = True
            self.events.append((ts, "perte hebdomadaire maximale atteinte"))
        if not self.killed and (self.peak - equity) / self.peak >= self.p.max_drawdown:
            self.killed = True
            self.events.append((ts, "drawdown maximal atteint - KILL SWITCH"))

    def halted(self):
        return self.killed or self.daily_halt or self.weekly_halt

    def reset(self):
        """Réarmement manuel obligatoire après un kill switch."""
        self.killed = self.daily_halt = self.weekly_halt = False
        self.peak = self.day_start = self.week_start = self.peak

    def allow_entry(self, atr_pct, n_open):
        if self.halted():
            return False, "trading arrêté (limite de perte)"
        if n_open >= self.p.max_positions:
            return False, "nombre maximal de positions atteint"
        if atr_pct is None or atr_pct != atr_pct or atr_pct > self.p.vol_limit:
            return False, "volatilité trop élevée / indisponible"
        return True, ""
