"""TRADER AI PRO - plateforme de trading algorithmique éducative (MVP)."""
DISCLAIMER = ("Les performances passées ne garantissent pas les performances futures. "
              "Le trading comporte un risque de perte en capital.")
