from . import DISCLAIMER


def explain(asset, dec):
    lines = [f"POURQUOI L'IA PREND CETTE DÉCISION ? — {asset}",
             f"Décision : {dec.action} | Score : {dec.score:.0f}/100 ({dec.label})", "Raisons :"]
    lines += [f"  ✓ {r}" for r in dec.reasons] or ["  (aucune)"]
    if dec.risks:
        lines += ["Risques :"] + [f"  ⚠ {r}" for r in dec.risks]
    return "\n".join(lines)


def summary(m):
    pf = "n/a" if m["profit_factor"] is None else f"{m['profit_factor']:.2f}"
    return (f"Rendement {m['return_pct']:+.2f}% | Drawdown max {m['max_drawdown_pct']:.2f}% | "
            f"Trades {m['trades']} | Win rate {m['win_rate_pct']:.0f}% | PF {pf} | Sharpe {m['sharpe']:.2f} | "
            f"Série de pertes max {m['max_losing_streak']}")


def disclaimer():
    return DISCLAIMER
