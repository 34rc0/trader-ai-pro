import numpy as np
import pandas as pd


def compute_metrics(equity, trades, periods_per_year):
    eq = pd.Series(equity, dtype=float)
    ret = eq.pct_change().dropna()
    pnl = [t["pnl"] for t in trades]
    wins = [p for p in pnl if p > 0]
    losses = [p for p in pnl if p <= 0]
    streak = cur = 0
    for p in pnl:
        cur = cur + 1 if p <= 0 else 0
        streak = max(streak, cur)
    std = ret.std() if len(ret) > 1 else 0.0
    return {
        "return_pct": float(eq.iloc[-1] / eq.iloc[0] - 1) * 100 if len(eq) else 0.0,
        "max_drawdown_pct": float((eq / eq.cummax() - 1).min()) * 100 if len(eq) else 0.0,
        "trades": len(pnl),
        "win_rate_pct": 100 * len(wins) / len(pnl) if pnl else 0.0,
        "profit_factor": (sum(wins) / abs(sum(losses))) if losses and sum(losses) != 0 else None,
        "sharpe": float(ret.mean() / std * np.sqrt(periods_per_year)) if std and std > 0 else 0.0,
        "avg_win": float(np.mean(wins)) if wins else 0.0,
        "avg_loss": float(np.mean(losses)) if losses else 0.0,
        "max_losing_streak": streak,
        "volatility_pct": float(std * np.sqrt(periods_per_year)) * 100,
    }
