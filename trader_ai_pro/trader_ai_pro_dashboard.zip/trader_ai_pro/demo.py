"""Démo sur données SYNTHÉTIQUES (ou CSV): python demo.py [--csv fichier.csv] [--regime bull] [--risk MEDIUM]"""
import argparse
from trader_ai_pro import data, report
from trader_ai_pro.backtest import run_splits

ap = argparse.ArgumentParser()
ap.add_argument("--csv"); ap.add_argument("--regime", default="bull"); ap.add_argument("--risk", default="MEDIUM")
a = ap.parse_args()
df = data.load_csv(a.csv) if a.csv else data.synthetic(a.regime, n=3000)
print("Données :", "CSV " + a.csv if a.csv else "SYNTHÉTIQUES (régime %s) - pas de vraies performances" % a.regime)
probs = data.validate_ohlc(df)
if probs:
    raise SystemExit("Données invalides: " + "; ".join(probs))
for name, res in run_splits(df, risk_level=a.risk).items():
    print(f"[{name:13}] {report.summary(res['metrics'])}")
print(report.disclaimer())
